# Nexa Finance — Android project

A premium navy, emerald, and gold personal-finance tracker starter project.

## Features in this build
- Local account registration and login (stored on this device only)
- SQLite transaction storage scoped by username
- Record income and expenses with amount, category, notes, and date
- Balance, total income, and total expense summary
- Transaction history and delete confirmation
- Export transaction history to CSV through Android's save-file picker
- Custom navy-and-gold Nexa monogram app icon and premium-style interface
- GitHub Actions workflow to build a debug APK

## Build APK with GitHub Actions
1. Create a GitHub repository (for example, `NexaFinance`).
2. Extract this ZIP and upload **the contents of the `NexaFinance` folder** to the repository root. The `.github` folder must be at the repository root.
3. Open **Actions** and run **Build Nexa Finance APK** (or push a commit to `main`).
4. Open the successful workflow run and download the `Nexa-Finance-APK` artifact. Extract it to get `app-debug.apk`.

## Important limitations
This is a starter build, not a fully audited finance app. Data is local to the device; there is no cloud sync or account recovery. Passwords are hashed, but transaction data is not encrypted at rest. CSV export is implemented; import/restore, date filters, budgets, recurring transactions, and richer charts are not implemented in this build yet. Keep a separate backup of important data. Test the APK before relying on it for important financial records.
